const crypto = require("crypto");

const { ACCESS_SECRET } = require('../main.config');

module.exports = {ACCESS_SECRET};