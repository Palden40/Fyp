const courseModel = require('../../models/entities/course.model');
const customError = require('../../error/CustomAPIError');
const EnrolledUser = require('../../models/entities/enrolledUser.model');
const { StatusCodes } = require('http-status-codes');
const userModel = require('../../models/user.model');

const createCourse = (req, res, next) => {
    const { body } = req;
    const {id: teacherId} = req.user;
    if (teacherId) {
        body.teacherId = teacherId;
    }
    console.log(body);
    new courseModel({
        ...body,
    })
        .save()
        .then((savedCourse) => {
            return res.status(201).json({
                savedCourse,
                message: 'Course added successfully!',
            });
        })
        .catch((err) => next(err));
};

const getCourse = async (req, res, next) => {
    const {
        category,
        search: courseName,
        hadDiscount,
        language,
        minPrice,
        maxPrice,
    } = req.query;

    const filters = {};

    if (category) {
        filters.category = category;
    }

    if (courseName) {
        filters.courseName = { $regex: new RegExp(courseName, 'i') };
    }

    if (hadDiscount) {
        filters.hadDiscount = hadDiscount;
    }

    if (language) {
        filters.language = language;
    }

    if (minPrice || maxPrice) {
        filters.price = {};
        if (minPrice) {
            filters.price.$gte = minPrice;
        }
        if (maxPrice) {
            filters.price.$lte = maxPrice;
        }
    }
    console.log(filters);
    
    if (req.user?.role === "admin") {
        filters.teacherId = req.user.id;
    }

    courseModel
        .find(filters)
        .then((allCourse) =>
            res.json({
                allCourse,
            })
        )
        .catch((err) => next(err));
};

const addCourseContent = async (req, res) => {
    const { id: courseId } = req.params;
    const course = await courseModel.findById(courseId);
    if (!course) {
        throw new customError(`No course with id: ${courseId}`, 404);
    }

    if (course.teacherId !== req.user.id) {
        throw new customError('You cannot edit or delete this course.', 403);
    }

    const updatedCourse = await courseModel.findByIdAndUpdate(courseId, {
        $push: {
            content: {
                ...req.body
            },
        },
    });

    return res.status(StatusCodes.OK).json({ message: "Successfully added course content!", updatedCourse })
}

const addCourseContents = async (req, res) => {
    const { id: courseId } = req.params;
    const course = await courseModel.findById(courseId);
    if (!course) {
        throw new customError(`No course with id: ${courseId}`, 404);
    }

    if (course.teacherId !== req.user.id) {
        throw new customError('You cannot edit or delete this course.', 403);
    }

    const updatedCourse = await courseModel.findByIdAndUpdate(courseId, {
        $push: {
            content: {
                $each: req.body.contents
            },
        },
    });

    return res.status(StatusCodes.OK).json({ message: "Successfully added course content!", updatedCourse })
}

const getCourseById = (req, res, next) => {
    const { id } = req.params;

    courseModel
        .findById(id)
        .then((foundCourse) => {
            res.json({
                foundCourse,
            });
        })
        .catch((err) => next(err));
};

const updateCourse = async (req, res, next) => {
    const {
        params: { id: courseId },
        body,
    } = req;
    const course = await courseModel.findById(courseId);
    if (!course) {
        throw new customError(`No course with id: ${courseId}`, 404);
    }
    console.log("Course.teacherId: ",course.teacherId)
    console.log("req.user.id: ",req.user.id)
    if (course.teacherId.toString() !== req.user.id.toString()) {
        throw new customError('You cannot edit or delete this course.', 403);
    }

    courseModel
        .findById(courseId)
        .then((course) => {
            if (!course) {
                return res.status(404).json({
                    message: 'Course not found!',
                });
            }
            Object.keys(body).forEach((key) => {
                course[key] = body[key];
            });
            return course.save();
        })
        .then((updatedCourse) => {
            return res.status(200).json({
                message: 'Course updated successfully!',
                updatedCourse,
            });
        })
        .catch((err) => next(err));
};

const deleteCourse = async (req, res, next) => {
    const { id: courseId } = req.params;
    
    const course = await courseModel.findById(courseId);
    if (!course) {
        throw new customError(`No course with id: ${courseId}`, 404);
    }

    if (course.teacherId !== req.user.id) {
        throw new customError('You cannot edit or delete this course.', 403);
    }

    courseModel
        .findByIdAndDelete(courseId)
        .then((deletedCourse) => {
            return res.status(204).json({
                message: 'course deleted!',
                deletedCourse,
            });
        })
        .catch((err) => next(err));
};

const enrollCourse = async (req, res) => {
    const { id: courseId } = req.params;
    const { id: userId } = req.user;

    try {
        const course = await courseModel.findById(courseId);
        if (!course) {
            return res.status(StatusCodes.NOT_FOUND).json({ message: 'No course with that id' });
        }

        // Check if user has already enrolled in that particular course
        const isEnrolled = await EnrolledUser.findOne({ courseId, userId });
        if (isEnrolled) {
            return res.status(StatusCodes.OK).json({ success:false, message: 'You have already enrolled in this course' });
        }

        // Create a new enrolled user object
        const enrolled = new EnrolledUser({
            courseId,
            userId,
            enrolled_Date: new Date().toLocaleDateString(),
            completed_date: null,
            isCompleted: false,
        });

        await enrolled.save();
        await enrolled.populate('courseId');

        return res.status(201).json({
            message: 'You have successfully enrolled in this course',
            enrolled,
        });
    } catch (error) {
        console.log(error);
        throw new customError(error.message, 500);
    }
};

const unenrollCourse = async (req, res) => {
    const { id: courseId } = req.params;
    const { id: userId } = req.user;

    try {
        const course = await courseModel.findById(courseId);
        if (!course) {
            throw new customError(`No course with id: ${courseId}`, 404);
        }

        // Check if user has already enrolled in that particular course
        const isEnrolled = await EnrolledUser.findOne({ courseId, userId });
        if (isEnrolled) {
            await EnrolledUser.findOneAndDelete({ courseId, userId });
        }

        res.status(StatusCodes.OK).json({
            message: 'You have successfully unenrolled in this course',
        });
    } catch (error) {
        console.log(error);
        throw new customError(error.message, 500);
    }
};

const getEnrollUsers = async (req, res) => {
    const { id: courseId } = req.params;
    let enrollUsers = (await EnrolledUser.find({ courseId })).toObject();
    if (!enrollCourse.length) {
        throw new customError('No Enroll user found!!!', StatusCodes.NOT_FOUND);
    }
    enrollUsers = await Promise.all(enrollUsers.map(async (enrollUser) => {
        enrollUser.user = await userModel.findById(enrollUser.userId);
        enrollUser.course = await courseModel.findById(enrollUser.courseId);
        return enrollUser;
    }));

    res.status(200).json({ msg: 'Fetched successfully', enrollUsers });
};

const getEnrollUser = async (req, res) => {
    let enrollUsers = (await EnrolledUser.find({
        userId: req.user.id,
    })).map(o=>o.toObject());
    if (enrollUsers.length === 0) {
        throw new customError(
            `you have not enroll to any courses yet!!!`,
            StatusCodes.NOT_FOUND
        );
    }
    
    enrollUsers=await Promise.all(enrollUsers.map(async (enrollUser) => {
        enrollUser.user = await userModel.findById(enrollUser.userId);
        enrollUser.course = await courseModel.findById(enrollUser.courseId);
        return enrollUser;
    }));

    res.status(200).json({ msg: 'Fetched successfully', enrollUsers });
};

const registerCompleted = async (req, res) => {
    const { id: courseId, contentId } = req.params;
    const { id: userId } = req.user;

    if (!courseId || !contentId) {
        return res.status(StatusCodes.BAD_REQUEST).json({ message: 'Invalid request, provide courseId as id and contentId in parameters.' });
    }

    try {
        const course = await courseModel.findById(courseId);
        if (!course) {
            return res.status(StatusCodes.NOT_FOUND).json({ message: 'No course with that id' });
        }

        const isEnrolled = await EnrolledUser.findOne({ courseId, userId });
        if (!isEnrolled) {
            return res.status(StatusCodes.BAD_REQUEST).json({ message: 'You have not enrolled in this course' });
        }

        let currentId = "";
        for (let i = 0; i < course.content.length; i++) {
            if (course.content[i]._id == contentId) {
                if (i === course.content.length - 1) {
                    currentId = null;
                } else {
                    currentId = course.content[i + 1]._id;
                }
                break;
            }
        }
        const completed = currentId === null;

        const updatedEnrolled = await EnrolledUser.findOneAndUpdate(
            { courseId, userId },
            {
                $push: {
                    'progress.completedIndexes': contentId,
                },
                'progress.lastIndex': contentId,
                'progress.currentIndex': currentId,
                completed
            },
            { new: true }
        );

        res.status(StatusCodes.OK).json({
            message: 'You have successfully registered the completed content',
            updatedEnrolled,
        });
    } catch (error) {
        console.log(error);
        throw new customError(error.message, 500);
    }
};

const checkEnrollUserByCourse = async (req, res) => {
    const enrollUser = await EnrolledUser.find({
        userId: req.user.id,
        courseId: req.params.id,
    });
    if (enrollUser.length === 0) {
        throw new customError(
            `you have not enroll to this course yet!!!`,
            StatusCodes.NOT_FOUND
        );
    }
    res.status(200).json({
        status: true,
        msg: 'You have enrolled in this course',
        data: enrollUser,
    });
};


module.exports = {
    deleteCourse,
    createCourse,
    getCourse,
    getCourseById,
    updateCourse,
    enrollCourse,
    unenrollCourse,
    getEnrollUser,
    getEnrollUsers,
    checkEnrollUserByCourse,
    addCourseContent,
    addCourseContents,
    registerCompleted,
};
